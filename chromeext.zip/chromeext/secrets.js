process.env.GOOGLE_CLIENT_ID =
  "461757322451-6dtk0here3ocr3nt8jovg7kpb059p00i.apps.googleusercontent.com";
process.env.GOOGLE_CLIENT_SECRET = "m938sbtSNHf7mj2y-tECx_YQ";
process.env.GOOGLE_CALLBACK = "http://localhost:4000/auth/google/callback";
